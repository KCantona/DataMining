BM.jar is jar package of  Hadoop MapReduce program. It compiled by jdk 1.8. if use jdk 1.7, it would raise signature problem.
BlockMult.java is main class and contain main function, mapper and reduce function
MatrixItem.java, BlockItem.java are helper class
----------------------------------------------------
BlockMult.py is Spark in Python program.